import React from "react";


export default function LoadingSpinner() {
  return (
    
    <div class="content-center">
        <center>

    <div class="d-flex justify-content-center">
    <div class="spinner-border text-primary" role="status">
      <span class="sr-only"></span>
      {/* <img src={logo}></img> */}
      </div>
    </div>
    </center>
  </div>
 
  );
}